from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, get_object_or_404, redirect
from post.models import Post
from post.forms import PostForm
from django.contrib import messages


def home_page(request):
    return HttpResponse('<h1>Welcome to home page</h1>')


def post_list(request):
    queryset = Post.objects.all()
    context = {
        'title': 'Post list',
        'objects_list': queryset
    }
    return render(request, 'index.html', context)


def post_update(request, id=None):
    instance = get_object_or_404(Post, id=id)
    form = PostForm(request.POST or None, instance=instance)
    if form.is_valid():
        instance = form.save(commit=False)
        instance.save()
        messages.success(request, '<a href="#">item</a> updated', extra_tags='html_safe')
        return HttpResponseRedirect(instance.get_absolute_url())

    context = {
        'title': 'Post update',
        'form': form
    }
    return render(request, 'post_form.html', context)


def post_create(request):
    form = PostForm(request.POST or None)

    if form.is_valid():
        instance = form.save(commit=False)
        instance.save()
        return HttpResponseRedirect(instance.get_absolute_url())
    # if request.POST:
    #     title = request.POST['title']
    #     content = request.POST['content']
    #     Post.objects.create(title=title,
    #                         content=content)
    #
    context = {
        'title': 'Post create',
        'form': form
    }

    return render(request, 'post_form.html', context)


def post_delete(request, id):
    instance = get_object_or_404(Post, id=id)
    instance.delete()
    messages.success(request, 'instance was deleted!!!')
    return redirect('post:post_list')


def post_detail(request, id=None):
    instance = get_object_or_404(Post, id=id)
    context = {
        'title': 'Post detail',
        'object': instance
    }

    return render(request, 'post_detail.html', context)
