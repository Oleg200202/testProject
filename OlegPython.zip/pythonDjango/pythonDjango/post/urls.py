from django.urls import path
from post.views import post_list, post_detail, post_delete, post_create, post_update

app_name = 'post'

urlpatterns = [
    path('', post_list, name='post_list'),
    path('create/', post_create, name='post_create'),
    path('detail/<int:id>/', post_detail, name='post_detail'),
    path('delete/<int:id>/', post_delete, name='post_delete'),
    path('update/<int:id>/', post_update, name='post_update')
]

