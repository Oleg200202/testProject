from django.db import models


class Post(models.Model):
    title = models.CharField(max_length=40)
    content = models.TextField()
    update = models.DateTimeField(auto_now=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    def get_absolute_url(self):
        return f'/post/detail/{self.id}'

    def __str__(self):
        return self.title



