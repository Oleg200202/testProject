from django.contrib import admin
from post.models import Post


class PostModelAdmin(admin.ModelAdmin):
    list_display = ('title', 'update', 'timestamp')
    list_display_links = ('update',)
    list_filter = ('timestamp', 'update')
    list_editable = ('title',)


admin.site.register(Post, PostModelAdmin)
